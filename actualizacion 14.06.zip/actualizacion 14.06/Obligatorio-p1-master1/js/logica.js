//  NUEVO
let s = new Sistema();
Inicio();


function Inicio(){
    EventosBotones()
    ArmarBotonera()
}


function ArmarBotonera() {
    // MENU
    document.querySelector("#botonera-deslogueado").style.display = "none";
    document.querySelector("#botonera-logueado-cliente").style.display = "none";
    document.querySelector("#botonera-logueado-paseador").style.display = "none";
    // SECTION
    document.querySelector("#seccion-registro").style.display = "none";
    document.querySelector("#seccion-login").style.display = "none";
    document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
    
    if(s.Logueado != null){//mustra el menno dependioendo el ususario 
        if(s.RolUsuarioLogueado === "cliente"){
            document.querySelector("#botonera-logueado-cliente").style.display = "block";
            
    }else if (s.RolUsuarioLogueado === "paseador"){
        document.querySelector("#botonera-logueado-paseador").style.display = "block";
            

    }   
    }else{
    document.querySelector("#botonera-deslogueado").style.display = "block";
            

    }
}
function EventosBotones() {
    document.querySelector("#btnNavegarLogin").addEventListener('click',menuLogin);
    document.querySelector("#btnNavegarRegistro").addEventListener('click',menuRegistrar);
    document.querySelector("#btnNavegarVerPaseadores").addEventListener('click',verPaseadores);
    document.querySelector("#btnNavegarVerListaPendiente").addEventListener('click',listaPendiente);
    document.querySelector("#btnNavegarVerListaTotal").addEventListener('click',listaTotal);
    document.querySelector("#btnNavegarGestionarClientes").addEventListener('click',gestionarClientes);
    document.querySelector("#btnNavegarVerListaContrataciones").addEventListener('click',listaContrataciones);
    document.querySelector("#btnregistrarse").addEventListener('click',registrarse);
    document.querySelector("#btnlogin").addEventListener('click',login);
   
    let botonesParaCerrarSesion = document.querySelectorAll(".btnNavegarCerrarSesion");
    for ( let btnCerrar of botonesParaCerrarSesion){
        btnCerrar.addEventListener("click", NavegarSesionCerrada)
    }
}

function ocultarSeccion(){
    // SECTION
    document.querySelector("#seccion-registro").style.display = "none";
    document.querySelector("#seccion-login").style.display = "none";
    document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
}

function ocultarMenu(){
    document.querySelector("#botonera-deslogueado").style.display = "none";
    document.querySelector("#botonera-logueado-cliente").style.display = "none";
    document.querySelector("#botonera-logueado-paseador").style.display = "none";
}


function menuRegistrar(){
    ocultarSeccion()
    document.querySelector("#seccion-registro").style.display = "block";
}

function menuLogin(){
    ocultarSeccion()
    document.querySelector("#seccion-login").style.display = "block";
}



function verPaseadores(){
ocultarSeccion()
document.querySelector("#seccion-ver-lista-paseadores").style.display = "block";
if(s.Logueado != null) {
    if(s.RolUsuarioLogueado == "cliente"){
        let cadena = ''
        for (let i of s.ObtenerPaseadoresCompatibles()){
            cadena += `
           <table>
      <thead>
        <tr>
          <th>Nombre: ${i.NombreDePaseador}</th>
          <th>Total de cupos: ${i.Cupos}</th>
          <th><button> Contratar </button>

        </tr>
      </thead>
      </table>
                
           
            `
        }
        document.querySelector("#tablaPaseadoresCompatibles").innerHTML = cadena

        

    }
}




    
}



function listaPendiente(){}
function listaTotal(){}
function gestionarClientes(){}
function listaContrataciones(){}


function registrarse(){
    let nomCliente = document.querySelector("#nombreDeUsuarioRegistro").value;
    let passCliente= document.querySelector("#passwordC").value;
    let nomPerro= document.querySelector("#nombrePerro").value;
    let tamPerro=  Number(document.querySelector("#tamanioMascota").value);
    

    let clienteNuevo = new Cliente (nomCliente, passCliente, nomPerro, tamPerro);
    let dioDeAlta = s.AltaCliente(clienteNuevo);
    

    if (dioDeAlta){
        document.querySelector("#error-register").innerHTML="Registro exitoso";
    }else{
        document.querySelector("#error-register").innerHTML = "Error en los datos";

    }

}


function login(){

    let nombre = document.querySelector("#nombreDeUsuario").value;
    let pass = document.querySelector("#password").value;
    
    s.BuscarUsuarioParaLogin(nombre,pass);//invoco la funcion para verificar si los datos son correctos 
    
    if(s.RolUsuarioLogueado ==  null){// si no guardo ningun objeto ...
        document.querySelector("#error-login").innerHTML = "El usuario y/o la contraseña son incorrectos";
        document.querySelector("#error-login").style.color= "red"

    }else if(s.RolUsuarioLogueado == "cliente"){// si el rol que asigne es...
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-cliente").style.display = "block";
        verPaseadores()
    }else if (s.RolUsuarioLogueado == "paseador") {
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-paseador").style.display = "block"; 
    }
}
function NavegarSesionCerrada(){
    s.Logueado = null; //saco el objeto del logueado para que quede en null
    s.RolUsuarioLogueado = null; // tambien le saco el rol 
    ArmarBotonera()
    

}


//linea 163 agregue verpaseadores() para que ya al iniciar como cliente se muestre la lista automaticamente