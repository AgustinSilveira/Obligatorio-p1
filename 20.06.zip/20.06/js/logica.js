//  NUEVO
let s = new Sistema();
Inicio();


function Inicio() {
  EventosBotones()
  ArmarBotonera()
}

// -------------------------- FUNCIONES GENERALES ----------------------------------------------------------------

function ArmarBotonera() {
  // MENU
  document.querySelector("#botonera-deslogueado").style.display = "none";
  document.querySelector("#botonera-logueado-cliente").style.display = "none";
  document.querySelector("#botonera-logueado-paseador").style.display = "none";
  // SECTION
  document.querySelector("#seccion-registro").style.display = "none";
  document.querySelector("#seccion-login").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
  document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
  document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores-pendientes").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores-totales").style.display = "none";




  if (s.Logueado != null) {//mustra el menno dependioendo el ususario 
    if (s.RolUsuarioLogueado === "cliente") {
      document.querySelector("#botonera-logueado-cliente").style.display = "block";

    } else if (s.RolUsuarioLogueado === "paseador") {
      document.querySelector("#botonera-logueado-paseador").style.display = "block";


    }
  } else {
    document.querySelector("#botonera-deslogueado").style.display = "block";


  }
}

function EventosBotones() {
  document.querySelector("#btnNavegarLogin").addEventListener('click', menuLogin);
  document.querySelector("#btnNavegarRegistro").addEventListener('click', menuRegistrar);
  document.querySelector("#btnNavegarVerPaseadores").addEventListener('click', verPaseadores);
  document.querySelector("#btnNavegarVerListaPendiente").addEventListener('click', listaPendiente);
  document.querySelector("#btnNavegarVerListaTotal").addEventListener('click', listaTotal);
  document.querySelector("#btnNavegarGestionarClientes").addEventListener('click', gestionarSolicitudesClientes);
  document.querySelector("#btnNavegarVerListaContrataciones").addEventListener('click', listaContrataciones);
  document.querySelector("#btnregistrarse").addEventListener('click', registrarse);
  document.querySelector("#btnlogin").addEventListener('click', login);

  let botonesParaCerrarSesion = document.querySelectorAll(".btnNavegarCerrarSesion");
  for (let btnCerrar of botonesParaCerrarSesion) {
    btnCerrar.addEventListener("click", NavegarSesionCerrada)
  }
}

function ocultarSeccion() {
  // SECTION
  document.querySelector("#seccion-registro").style.display = "none";
  document.querySelector("#seccion-login").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
  document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
  document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores-pendientes").style.display = "none";
  document.querySelector("#seccion-ver-lista-paseadores-totales").style.display = "none";


}

function ocultarMenu() {
  document.querySelector("#botonera-deslogueado").style.display = "none";
  document.querySelector("#botonera-logueado-cliente").style.display = "none";
  document.querySelector("#botonera-logueado-paseador").style.display = "none";
}


// ----------------------------- SOLO PARA EL CLIENTE -----------------------------------------------------------------------------

function verPaseadores() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-paseadores").style.display = "block";

  if (s.Logueado != null && s.RolUsuarioLogueado === "cliente") {
    let paseadores = s.ObtenerPaseadoresCompatibles();
    let tablaHTML = `
      <table>
        <thead>
          <tr>
            <th>Nombre del paseador</th>
            <th>Cupos disponibles</th>
            <th>Mandar solicitud</th>
          </tr>
        </thead>
        <tbody>
    `;

    for (let i of paseadores) {
      tablaHTML += `
        <tr>
          <td>${i.NombreDeUsuario}</td>
          <td>${i.Cupos}</td>
          <td><input id="btn-enviarSolicitud${i.Id}" type="button" class="botonesSolicitud" value="Enviar solicitud" /></td>
        </tr>
      `;
    }

    tablaHTML += `</tbody></table>`;

    document.querySelector("#tablaPaseadoresCompatibles").innerHTML = tablaHTML;
    let botones = document.querySelectorAll(".botonesSolicitud");
    for (b of botones) {
      b.addEventListener('click', mandarSolicitud);
    }

  }




}

// ---------------- EN CLASE ----------------------------------------
function mandarSolicitud() {
  let idBotonTocado = this.id;// traigo el id del boton que fue tocado
  idBotonTocado = idBotonTocado.substring(19);//limpio el id para quedarme con el numbre 

  let exito = s.MandarSolicitud(idBotonTocado); // voy al sistema para que mande la solicitud y le paso el id del botn
  if (exito) {
    document.querySelector("#pResSolicitud").innerHTML = 'Solicitud enviada con exito';
  } else {
    document.querySelector("#pResSolicitud").innerHTML = 'Ya haz realizado una solicitud';
  }
}
// ------------------------------------------------------------------

function registrarse() {
  let nomCliente = document.querySelector("#nombreDeUsuarioRegistro").value;
  let passCliente = document.querySelector("#passwordC").value;
  let nomPerro = document.querySelector("#nombrePerro").value;
  let tamPerro = Number(document.querySelector("#tamanioMascota").value);


  let clienteNuevo = new Cliente(nomCliente, passCliente, nomPerro, tamPerro);
  let dioDeAlta = s.AltaCliente(clienteNuevo);


  if (dioDeAlta) {
    document.querySelector("#error-register").innerHTML = "Registro exitoso";
  } else {
    document.querySelector("#error-register").innerHTML = "Error en los datos";

  }

}

function listaContrataciones() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-clientes").style.display = "block";

  let tablaHTML = `
      <table>
        <thead>
          <tr>
            <th>Nombre del paseador</th>
            <th>Cupos disponibles</th>
          </tr>
        </thead>
        <tbody>
    `;

  for (let i of s.Cliente) {
    tablaHTML += `
        <tr>
          <td>${i.NombreDeUsuario}</td>  
          <td>${i.Cupos}</td>  
          
        </tr>
      `;// agregar cantidad de perros asignados 
  }
  tablaHTML += `</tbody></table>`;

  document.querySelector("#seccion-ver-lista-paseadores-totales").innerHTML = tablaHTML;

}

function listaTotal() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-paseadores-totales").style.display = "block";

  let tablaHTML = `
      <table>
        <thead>
          <tr>
            <th>Nombre del paseador</th>
            <th>Cupos disponibles</th>
          </tr>
        </thead>
        <tbody>
    `;

  for (let i of s.Paseador) {
    tablaHTML += `
        <tr>
          <td>${i.NombreDeUsuario}</td>  
          <td>${i.Cupos}</td>  
          
        </tr>
      `;// agregar cantidad de perros asignados (numero)
  }
  tablaHTML += `</tbody></table>`;

  document.querySelector("#seccion-ver-lista-paseadores-totales").innerHTML = tablaHTML;

}

function listaPendiente() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-paseadores-pendientes").style.display = "block";
  // let lista = s.ListaPaseadoresPendientes();
  //let pendientes = s.ContratacionesDelLogeado()

  let tablaHTML = `
      <table>
        <thead>
          <tr>
            <th>Nombre del paseador</th>
            <th>Cupos disponibles</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
    `;


  if (s.TieneSoli()) {
    let contratacion = s.ContratacionLogueado();
    tablaHTML += `
        <tr> 
          <td>${contratacion.Paseador.NombreDePaseador}</td>  
          <td>${contratacion.Paseador.Cupos}</td>  
          <td><input class="btnCancelarSolicitud" id="${contratacion.Id}" type="button" value="Cancelar"></td>  
          
        </tr>
        `

    tablaHTML += `</tbody></table>`;
    document.querySelector("#tablaPendientes").innerHTML = tablaHTML;
    document.querySelector(".btnCancelarSolicitud").addEventListener("click", cancelarSolicitud);
    document.querySelector("#parrafoPendiente").innerHTML = "";



  } else {
    document.querySelector("#parrafoPendiente").innerHTML = `No hay solicitudes pendientes por el momento`;
    document.querySelector("#parrafoPendiente").style.color = "red"
  }

}

function cancelarSolicitud() {
  let idBtnTocado = this.id;

  let solicitud = s.CancelarSolicitud(idBtnTocado);
  if (solicitud) {
    listaPendiente();
    document.querySelector("#tablaPendientes").innerHTML = "";

  }


}




// ----------------------------- SOLO PARA EL PASEADOR -----------------------------------------------------------------------------

function listaContrataciones() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "block";


}

function gestionarSolicitudesClientes() {
  ocultarSeccion();
  document.querySelector("#seccion-ver-lista-clientes").style.display = "block";

  let tablaHTML = `
      <table>
        <thead>
          <tr>
            <th>Nombre del cliente</th>
            <th>Nombre del perro</th>
            <th>Tamaño del perro</th>
            <th>Estado</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
    `;

  for (let i of s.Contrataciones) { // recorro conrataciones 
    if (s.GetContrataciones(i)) { //busco el id del logueado (paseador) entre las contrataciones y las inyecto en la tabla
      tablaHTML += `
        <tr>
          <td>${i.Cliente.NombreDeCliente}</td>  
          <td>${i.Cliente.NombreDelPerro}</td>  
          <td>${i.Cliente.TamañoPerro}</td>    
          <td>${i.Estado}</td>  
          <td><input type= "button" value= "Aceptar" id="btnAceptar${i.Id}" class= "botonAceptar"></td>  
          
        </tr>
      `;
      document.querySelector("#parrafoSolicitudes").innerHTML = "";

    } else {
      document.querySelector("#listaSolicitudes").innerHTML = "";
      document.querySelector("#parrafoSolicitudes").innerHTML = `No hay solicitudes pendientes por el momento :(`;
      document.querySelector("#parrafoSolicitudes").style.color = "red"
    }
}
    tablaHTML += `</tbody></table>`;

    document.querySelector("#listaSolicitudes").innerHTML = tablaHTML;
    let botones = document.querySelectorAll(".botonAceptar");
    for (b of botones) {
      b.addEventListener('click', aceptarSolicitud);
    }
  
  }
    function aceptarSolicitud(){
      let idBotonTocado = this.id;// traigo el id del boton que fue tocado
      idBotonTocado = idBotonTocado.substring(10);//limpio el id para quedarme con el numbre 

      let exito = s.AceptarSolicitud(idBotonTocado); // voy al sistema para que mande la solicitud y le paso el id del botn
      if (exito) {
        document.querySelector("#pResAceptacion").innerHTML = 'Solicitud aceptada con exito';
      } 
  }
    // ----------------------------- PASEADOR Y CLIENTE -----------------------------------------------------------------------------

    function menuRegistrar() {
      ocultarSeccion()
      document.querySelector("#seccion-registro").style.display = "block";
    }

    function menuLogin() {
      ocultarSeccion()
      document.querySelector("#seccion-login").style.display = "block";
    }

    function login() {

      let nombre = document.querySelector("#nombreDeUsuario").value;
      let pass = document.querySelector("#password").value;

      s.BuscarUsuarioParaLogin(nombre, pass);//invoco la funcion para verificar si los datos son correctos 

      if (s.RolUsuarioLogueado == null) {// si no guardo ningun objeto ...
        document.querySelector("#error-login").innerHTML = "El usuario y/o la contraseña son incorrectos";
        document.querySelector("#error-login").style.color = "red"

      } else if (s.RolUsuarioLogueado == "cliente") {// si el rol que asigne es...
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-cliente").style.display = "block";
        verPaseadores();
      } else if (s.RolUsuarioLogueado == "paseador") {
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-paseador").style.display = "block";
        gestionarSolicitudesClientes()
      }
    }


    function NavegarSesionCerrada() {
      s.Logueado = null; //saco el objeto del logueado para que quede en null
      s.RolUsuarioLogueado = null; // tambien le saco el rol 
      ArmarBotonera();


    }
