let s = new Sistema();
Inicio();


function Inicio(){
    EventosBotones()
    ArmarBotonera()
}


function ArmarBotonera() {
    // MENU
    document.querySelector("#botonera-deslogueado").style.display = "none";
    document.querySelector("#botonera-logueado-cliente").style.display = "none";
    document.querySelector("#botonera-logueado-paseador").style.display = "none";
    // SECTION
    document.querySelector("#seccion-registro").style.display = "none";
    document.querySelector("#seccion-login").style.display = "none";
    document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
    
    if(s.LogueadoId){//mustra el menno dependioendo el ususario 
        if(s.LogueadoId.Rol === "Cliente"){
            document.querySelector("#botonera-logueado-cliente").style.display = "block";
            console.log("login cliente")
    }else{
        document.querySelector("#botonera-logueado-paseador").style.display = "block";
            console.log("login paseador")

    }   
    }else{
    document.querySelector("#botonera-deslogueado").style.display = "block";
            console.log("login o register")

    }
}
function EventosBotones() {
    document.querySelector("#btnNavegarLogin").addEventListener('click',menuLogin);
    document.querySelector("#btnNavegarRegistro").addEventListener('click',menuRgistrar);
    document.querySelector("#btnNavegarVerPaseadores").addEventListener('click',verPaseadores);
    document.querySelector("#btnNavegarVerListaPendiente").addEventListener('click',listaPendiente);
    document.querySelector("#btnNavegarVerListaTotal").addEventListener('click',listaTotal);
    document.querySelector("#btnNavegarGestionarClientes").addEventListener('click',gestionarClientes);
    document.querySelector("#btnNavegarVerListaContrataciones").addEventListener('click',listaContrataciones);
    document.querySelector("#btnregistrarse").addEventListener('click',registrarse);
    document.querySelector("#btnlogin").addEventListener('click',login);
   
    let botonesParaCerrarSesion = document.querySelectorAll(".btnNavegarCerrarSesion");
}
function ocultarSeccion(){
    // SECTION
    document.querySelector("#seccion-registro").style.display = "none";
    document.querySelector("#seccion-login").style.display = "none";
    document.querySelector("#seccion-ver-lista-paseadores").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes").style.display = "none";
    document.querySelector("#seccion-ver-lista-clientes-aceptados").style.display = "none";
}

function ocultarMenu(){
    document.querySelector("#botonera-deslogueado").style.display = "none";
    document.querySelector("#botonera-logueado-cliente").style.display = "none";
    document.querySelector("#botonera-logueado-paseador").style.display = "none";
}

function menuRgistrar(){
    ocultarSeccion()
    document.querySelector("#seccion-registro").style.display = "block";
}
function menuLogin(){
    ocultarSeccion()
    document.querySelector("#seccion-login").style.display = "block";
}
function verPaseadores(){}
function listaPendiente(){}
function listaTotal(){}
function gestionarClientes(){}
function listaContrataciones(){}
function registrarse(){}
function login(){

    let nombre = document.querySelector("#nombreDeUsuario").value;
    let pass = document.querySelector("#password").value;
    let rolUsuario = s.BuscarUsuarioParaLogin(nombre,pass);//invoco la funcion para verificar si los datos son correctos 
    if(rolUsuario ==  undefined){
        document.querySelector("#error-login").innerHTML = "El usuario y/o la contraseña son incorrectos";
        document.querySelector("#error-login").style.color= "red"

    }else if(rolUsuario.Rol == "cliente") {
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-cliente").style.display = "block";
    }else if (rolUsuario.Rol == "paseador") {
        ocultarMenu();
        document.querySelector("#seccion-login").style.display = "none";
        document.querySelector("#botonera-logueado-paseador").style.display = "block"; 
    }
}