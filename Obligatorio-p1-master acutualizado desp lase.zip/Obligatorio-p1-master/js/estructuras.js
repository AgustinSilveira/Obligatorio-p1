class Cliente { // clase usuarios, retiene los datos para crear cada uno
    static idCliente = 1;
    constructor(nombreDeCliente, password, nombreDelPerro,cupoPerro, tamañoPerro ) {
        this.Id = Cliente.idCliente++;
        this.NombreDeCliente = nombreDeCliente;
        this.Password = password;
        this.NombreDelPerro = nombreDelPerro;
        this.TamañoPerro = tamañoPerro;
        this.CupoPerro = cupoPerro;
        this.Rol = "Cliente";
        this.Estado = true;
    }
}
class Paseador { // clase paseador, retiene los datos para crear cada uno
    static idPaseador = 1;
    constructor(nombreDePaseador, password,cupos) {
        this.Id = Cliente.idCliente++;
        this.NombreDePaseador = nombreDePaseador;
        this.Password = password;
        this.Rol = "Paseador";
        this.Cupos = cupos;
        this.Estado = true;
    }
}

class Contrataciones{
constructor() {
    this.Id = id
        
}
}

class Sistema { 
    constructor() {
        this.LogeadoId = null;
        this.HayLogeado = false;
        this.Cliente = new Array(); //lista clientes
        this.Paseador = new Array(); // lista paseadores 
        this.Contrataciones = new Array(); // lista de contrataciones
        this.PrecargarDatos(); //invoco la lista paseadores precargados
    }

AltaCliente(_cliente) { // agrega un cliente nuevo a la lista
    this.Cliente.push(_cliente);
    return _cliente;
}

AltaPaseador(_paseador) { // agrega un paseador nuevo a la lista
    this.Paseador.push(_paseador);
    return _paseador;
}

ListaDeClientes(){// devuelve la lista de usuarios, es un metodo. para no ir directamente a la lista 
        return this.Usuarios;
}


BuscarUsuarioParaLogin(n,p){
        for(let cliente of this.Cliente){ // por cada cliente de la lista de clientes verificar si el los parametros se encuentran en la lista 
            if(cliente.NombreDeCliente ==n && cliente.Password==p){
                return cliente;
            }
        }
        for(let paseador of this.Paseador){ //por cada paseador de la lista de paseadores verificar lo mismo
            if(paseador.NombreDePaseador ==n && paseador.Password==p) {
                return paseador;
            }
        }
        return null;

    }


ValidarDatosRegister(usu,pass,nomPerro,tipo) {
    
    if (usu === "" || pass === "" || nomPerro === "" || tipo === "-1"){// si los campos de texto no son vacios guardar usuario y dar paso a la pagina correspondiente
        return "faltan datos"
    } else {return true}
}

    



PrecargarDatos () {// paseadordes
   this.AltaPaseador(new Paseador("Juan6", "Juan12345" ,"Juan", 9))
   this.AltaPaseador(new Paseador("Lucas2", "Lucas12345", "Lucas", 6))
   this.AltaPaseador(new Paseador("Julieta13", "Julieta12345", "Julieta", 7))
   this.AltaPaseador(new Paseador("Gabriel123", "Gabriel12345", "Gabriel", 9))
   this.AltaPaseador(new Paseador("Martin5", "Martin12345", "Martin", 10))

}

}







