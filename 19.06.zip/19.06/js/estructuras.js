class Cliente { //clase usuarios, retiene los datos para crear cada uno
    static idCliente = 1;
    constructor(nombreDeCliente, password, nombreDelPerro,tamañoPerro) {
        this.Id = Cliente.idCliente++;
        this.NombreDeCliente = nombreDeCliente;
        this.Password = password; 
        this.NombreDelPerro = nombreDelPerro;
        this.TamañoPerro = tamañoPerro;
        this.Estado = true;
    }
}
class Paseador { //clase paseador, retiene los datos para crear cada uno
    static idPaseador = 1;
    constructor(nombreDePaseador, password, nombreDeUsuario, cupos) {
        this.Id = Paseador.idPaseador++;
        this.NombreDePaseador = nombreDePaseador;
        this.Password = password;
        this.NombreDeUsuario = nombreDeUsuario;
        this.Cupos = cupos;
        this.Contrataciones = Contratacion;
        this.Estado = true;
    }
}

class Contratacion{ 
    static ultimoIdContratacion = 1;
    constructor(cliente, paseador) {
        this.Id = Contratacion.ultimoIdContratacion++;
        this.Cliente = cliente;
        this.Paseador = paseador;
        this.Estado = "pendiente"; //cancelada, pendiente, aceptado
    }
}
        
class Sistema { 
    constructor() {
        this.Logueado = null;//si esta logueado
        this.RolUsuarioLogueado = null; // asigno un rol al usuario que esta logueado en vez de martillarlo
        this.Cliente = new Array(); //lista clientes
        this.Paseador = new Array(); //lista paseadores 
        this.Contrataciones = new Array(); //lista de contrataciones
        this.PaseadoresCompatibles = new Array();
        this.PrecargarDatos(); //invoco la lista paseadores precargados
    }

AltaCliente(_cliente) { //agrega un cliente nuevo a la lista
    if(_cliente != null){//verifico que los datos del registro sean correcto 
        if ( _cliente.NombreDeCliente.trim()!= "" &&  
        _cliente.NombreDelPerro != "" && //que los campos de texto no sean vacios
        _cliente.TamañoPerro != "0" &&
      this.ContraseñaValida(_cliente.Password) &&
      !this.UsuarioYaExistente(_cliente.NombreDeCliente)) {

      this.Cliente.push(_cliente);
      return true;
  }
  return false;
}
}

UsuarioYaExistente(unNombre){
    for (let u of this.Paseador) {// recorro lista paseadores
            if (u.NombreDePaseador.toLowerCase() == unNombre.toLowerCase()) {
                return true;//si ya existe retorno true
            }
        }
        for (let u of this.Cliente) {
            if (u.NombreDeCliente.toLowerCase() == unNombre.toLowerCase()) {
                return true;
            }
        }
        return false;// si no existe retorno false

}


CancelarSolicitud(idBotonTocado){
    for(let soli of this.Contrataciones){
        if(soli.Id == idBotonTocado){
            soli.Estado = "cancelada";
            return true;
        }
    }return false;
}

//PRACTICO 4 EJERCICIO 9
ContraseñaValida(c){ // mínimo 5 caracteres, incluyendo al menos una mayúscula, una minúscula y un número
    let cumpleLargo = false
    let tieneMinus= false
    let tieneMayus= false
    let tieneNumero = false
    
    
    if(c.length>=5){ // si cumple el largo
        cumpleLargo= true
    }
    
    for(let i=0; i<c.length;i++){ //si tiene Mayusculas
        if(c.charCodeAt(i)>=65 && c.charCodeAt(i)<=90){
            tieneMayus= true
    }}

    for(let i=0; i<c.length;i++){ //tiene numero
        if(c.charCodeAt(i)>=48 && c.charCodeAt(i)<=57){
            tieneNumero = true
        }}
    
    for(let i=0; i<c.length; i++){ //tiene minuscula
        if(c.charCodeAt(i)>=97 && c.charCodeAt(i)<=122){
            tieneMinus = true
        }}
    
    if(cumpleLargo && tieneMayus && tieneMinus && tieneNumero){ // si cumplen todas...
        return true;
    }else{
        return false;
    
    }
}

AltaSolicitud(idPas){
    if(idPas != null){
        this.Contrataciones.push(idPas)
        return true;
    }return false;
}

MandarSolicitud(idBotonTocado) {// recivo el id del btn tocado 
    let paseadorASolicitar = this.GetPaseadorById(idBotonTocado); // busco con la fincion getBy Id al paseador con el mismo id que el boton y le paso el boton tocado 
     
    let yaSolicitado = this.TieneSoli();// verifico si ya tiene una solicitud 

    if(!yaSolicitado){
        let paseadorNuevo = new Contratacion(this.Logueado, paseadorASolicitar);
        let exitoSolicitud = this.AltaSolicitud(paseadorNuevo);
        return exitoSolicitud;
    }else {
        return false;
    }
}

//ContratacionesDelLogeado() {
//let listaRetorno = new Array()
//for(let p of this.Contrataciones){
//    if(p.Cliente.Id == this.Logueado.Id) {
//        listaRetorno.push(p);
//    }
//}return listaRetorno;
//}
 
GetPaseadorById(idBtnTocado) {// reciv  id del btnTocado 
    for (let p of this.Paseador){//  p recorre la lista de paseadores 
        if(p.Id == idBtnTocado) { // si el id del paseador donde se encuentra p es igual al id del boton tocado 
            return p; // devuelvo el paseador con el mismo id 
        }
    }
    return null;
}

TieneSoli() { //
    for(let p of this.Contrataciones) {
        if(this.Logueado.Id == p.Cliente.Id && p.Estado == "pendiente") {
            return true;
        }
    }return false;
}

ContratacionLogueado(){
    for(let p of this.Contrataciones) {
        if(this.Logueado.Id == p.Cliente.Id && p.Estado === "pendiente") {
            return p;
        }
    }return null;   
}

AltaPaseador(_paseador) { //agrega un paseador nuevo a la lista
    this.Paseador.push(_paseador);
    return _paseador;
}

ListaDeClientes(){ //devuelve la lista de usuarios, es un metodo. para no ir directamente a la lista 
        return this.Usuarios;
}

BuscarUsuarioParaLogin(n,p){
        for(let cliente of this.Cliente){ //por cada cliente de la lista de clientes verificar si los parametros se encuentran en la lista 
            if(cliente.NombreDeCliente ==n && cliente.Password==p){
                this.RolUsuarioLogueado = "cliente" // asigno rol
                this.Logueado = cliente; //guardo el objeto entero en logueado 
                return cliente;
            }
        }
        for(let paseador of this.Paseador){ //por cada paseador de la lista de paseadores verificar lo mismo
            if(paseador.NombreDePaseador ==n && paseador.Password==p) {
                this.RolUsuarioLogueado = "paseador";
                this.Logueado = paseador;
                return paseador;
            }
        }
        return null;

}



CalcularCuposDisponibleDeUnPaseador(paseador){ //detarmina los cupos disponibles para un paseador 
	let cuposOcupados = 0;
	
	for(let cont of this.Contrataciones){  //recorro la lista de paseadores 
			if(cont.Paseador == paseador){ //si el paseador es el asignado
				cuposOcupados += cont.Cliente.TamañoPerro; //le sumo el cupo del perro
			}
	}
	return paseador.Cupos - cuposOcupados; //se lo resto al total de cupos del paseador asi me devuelve los cupos que le quedan
		
}

ObtenerPaseadoresCompatibles(){
     this.PaseadoresCompatibles = []; //vaciamos la lista

	let tamanio = this.Logueado.TamañoPerro; //identifico el tamanio del perro de la persona que esta logueada

	
	for(let paseador of this.Paseador){ //recorro la lista
		let cuposDisponiblesDeEstePaseador = this.CalcularCuposDisponibleDeUnPaseador(paseador); //llamo a la fincion pqra que me calcule los cupos dispoibles que tiene 

		
		if(tamanio === 4){   // perro grande
			if(cuposDisponiblesDeEstePaseador >= tamanio && !this.ContienePerroChico(paseador)){ //aplico las condiciones de la letra para que lo muestre si tiene cupos y no tiene un perro que no sea compatible 
				this.PaseadoresCompatibles.push(paseador)
			}
		}
		
		if(tamanio === 1){  // perro chico
			if(cuposDisponiblesDeEstePaseador >= tamanio && !this.ContienePerroGrande(paseador)){ //lo mismo
				this.PaseadoresCompatibles.push(paseador)
			}
		} else if (tamanio === 2) {//perro mediano
            if(cuposDisponiblesDeEstePaseador >= tamanio) { 
                this.PaseadoresCompatibles.push(paseador)
            }
        }
        
	}
	 return this.PaseadoresCompatibles
}

//VERIFICACION DE TAMANIOS
ContienePerroGrande(paseador){ 
	
	for(let cont of this.Contrataciones){ //reccorro la lista de contrataciones 
		if(cont.Paseador === paseador && cont.Cliente.TamañoPerro == 4){ 
		 return true
		}
		
	}
	return false;
}

ContienePerroChico(paseador){
    for(let cont of this.Contrataciones){
		if(cont.Paseador === paseador && cont.Cliente.TamañoPerro === 1){
		 return true
		}

	}
	return false;
	
}


//PASEADORES
PrecargarDatos () { 
   this.AltaPaseador(new Paseador("Juan6", "Juan12345" ,"Juan", 9))           //1
   this.AltaPaseador(new Paseador("Lucas2", "Lucas12345", "Lucas", 6))        //2
   this.AltaPaseador(new Paseador("Julieta13", "Julieta12345", "Julieta", 7)) //3
   this.AltaPaseador(new Paseador("Gabriel123", "Gabriel12345", "Gabriel", 9))//4
   this.AltaPaseador(new Paseador("Martin5", "Martin12345", "Martin", 1))     //5
   this.AltaPaseador(new Paseador("lucia2", "Lucia12345" ,"lucia", 1))        //6

   
// CLIENTES
this.AltaCliente(new Cliente("Juan", "Juan12345", "Firulais", 2, "Mediano"));//7 medianos
this.AltaCliente(new Cliente("Ana", "Ana12345", "Luna", 1, "Chico"));//6 chicos
this.AltaCliente(new Cliente("Carlos", "Carlos12345", "Rocky", 4, "Grande"));//7 grandes
this.AltaCliente(new Cliente("Lucia", "Lucia12345", "Nina", 2, "Mediano"));
this.AltaCliente(new Cliente("Pedro", "Pedro12345", "Max", 4, "Grande"));
this.AltaCliente(new Cliente("Sofia", "Sofia12345", "Boby", 1, "Chico"));
this.AltaCliente(new Cliente("Marcos", "Marcos12345", "Toby", 2, "Mediano"));
this.AltaCliente(new Cliente("Elena", "Elena12345", "Milo", 4, "Grande"));
this.AltaCliente(new Cliente("Jorge", "Jorge12345", "Simba", 1, "Chico"));
this.AltaCliente(new Cliente("Carla", "Carla12345", "Coco", 2, "Mediano"));
this.AltaCliente(new Cliente("Ernesto", "Ernesto12345", "Zeus", 4, "Grande"));
this.AltaCliente(new Cliente("Valeria", "Valeria12345", "Lola", 1, "Chico"));
this.AltaCliente(new Cliente("Diego", "Diego12345", "Oso", 2, "Mediano"));
this.AltaCliente(new Cliente("Marta", "Marta12345", "Chispa", 4, "Grande"));
this.AltaCliente(new Cliente("Nicolas", "Nicolas12345", "Thor", 1, "Chico"));
this.AltaCliente(new Cliente("Laura", "Laura12345", "Candy", 2, "Mediano"));
this.AltaCliente(new Cliente("Andres", "Andres12345", "Balto", 4, "Grande"));
this.AltaCliente(new Cliente("Paula", "Paula12345", "Nube", 1, "Chico"));
this.AltaCliente(new Cliente("Ruben", "Ruben12345", "Tiger", 2, "Mediano"));
this.AltaCliente(new Cliente("Clara", "Clara12345", "Bella", 4, "Grande"));

}


// CONTRATACIONES

}


// ListaPaseadoresPendientes(paseadorSolicitado){
//     let pendiente = new Array()
//     pendiente.push(paseadorSolicitado);
//     if (pendiente == undefined ){
//         return false;
//     }else{
//         return pendiente;
//     }

// }