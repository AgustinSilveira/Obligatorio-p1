class Cliente { //clase usuarios, retiene los datos para crear cada uno
    static idCliente = 1;
    constructor(nombreDeCliente, password, nombreDelPerro, tamañoPerro) {
        this.Id = Cliente.idCliente++;
        this.NombreDeCliente = nombreDeCliente;
        this.Password = password;
        this.NombreDelPerro = nombreDelPerro;
        this.TamañoPerro = tamañoPerro;
        this.Estado = true;
    }
}
class Paseador { //clase paseador, retiene los datos para crear cada uno
    static idPaseador = 1;
    constructor(nombreDePaseador, password, nombreDeUsuario, cupos) {
        this.Id = Paseador.idPaseador++;
        this.NombreDePaseador = nombreDePaseador;
        this.Password = password;
        this.NombreDeUsuario = nombreDeUsuario;
        this.Cupos = cupos;
        this.Contrataciones = Contratacion;
        this.Estado = true;
    }
}

class Contratacion { // retiene datos de paseador, cliente y un estado 
    static ultimoIdContratacion = 1;
    constructor(cliente, paseador) {
        this.Id = Contratacion.ultimoIdContratacion++;
        this.Cliente = cliente;
        this.Paseador = paseador;
        this.Estado = "pendiente"; //cancelada, pendiente, aceptado
    }
}

class Sistema { // contiene las listas de contratacion clientes paseadores paseadores compatibles y precarga los datos
    constructor() {
        this.Logueado = null;//si esta logueado
        this.RolUsuarioLogueado = null; // asigno un rol al usuario que esta logueado en vez de martillarlo
        this.Cliente = new Array(); //lista clientes
        this.Paseador = new Array(); //lista paseadores 
        this.Contrataciones = new Array(); //lista de contrataciones
        this.PaseadoresCompatibles = new Array();
        this.PrecargarDatos(); //invoco la lista paseadores precargados
    }

    
    AltaCliente(_cliente) { //agrega un cliente nuevo a la lista
        if (_cliente != null) {//verifico que los datos del registro sean correcto 
            if (_cliente.NombreDeCliente.trim() != "" &&
                _cliente.NombreDelPerro != "" && //que los campos de texto no sean vacios
                _cliente.TamañoPerro != "0" &&
                this.ContraseñaValida(_cliente.Password) &&
                !this.UsuarioYaExistente(_cliente.NombreDeCliente)) {

                this.Cliente.push(_cliente);
                return true;
            }
            return false;
        }
    }

    UsuarioYaExistente(unNombre) { // verifica si el usuario que esta intentando registrarse ya existe
        for (let u of this.Paseador) {// recorro lista paseadores
            if (u.NombreDePaseador.toLowerCase() == unNombre.toLowerCase()) {
                return true;//si ya existe retorno true
            }
        }
        for (let u of this.Cliente) {
            if (u.NombreDeCliente.toLowerCase() == unNombre.toLowerCase()) {
                return true;
            }
        }
        return false;// si no existe retorno false

    }


    CancelarSolicitud(idBotonTocado) { //cambia el estado de la solicitud a cancelada
        for (let soli of this.Contrataciones) {
            if (soli.Id == idBotonTocado) {
                soli.Estado = "cancelada";
                return true;
            }
        } return false;
    }

    //PRACTICO 4 EJERCICIO 9
    ContraseñaValida(c) { //verifica si la contraseña contiene: mínimo 5 caracteres, incluyendo al menos una mayúscula, una minúscula y un número
        let cumpleLargo = false
        let tieneMinus = false
        let tieneMayus = false
        let tieneNumero = false


        if (c.length >= 5) { // si cumple el largo
            cumpleLargo = true
        }

        for (let i = 0; i < c.length; i++) { //si tiene Mayusculas
            if (c.charCodeAt(i) >= 65 && c.charCodeAt(i) <= 90) {
                tieneMayus = true
            }
        }

        for (let i = 0; i < c.length; i++) { //tiene numero
            if (c.charCodeAt(i) >= 48 && c.charCodeAt(i) <= 57) {
                tieneNumero = true
            }
        }

        for (let i = 0; i < c.length; i++) { //tiene minuscula
            if (c.charCodeAt(i) >= 97 && c.charCodeAt(i) <= 122) {
                tieneMinus = true
            }
        }

        if (cumpleLargo && tieneMayus && tieneMinus && tieneNumero) { // si cumplen todas...
            return true;
        } else {
            return false;

        }
    }

    AltaSolicitud(idPas) { // da de alta una solicitud
        if (idPas != null) {
            this.Contrataciones.push(idPas)
            return true;
        } return false;
    }

    MandarSolicitud(idBotonTocado) {// verifica si el cliente ya tiene una solicitud mandada  
        let paseadorASolicitar = this.GetPaseadorById(idBotonTocado); // busco con la fincion getBy Id al paseador con el mismo id que el boton y le paso el boton tocado 

        let yaSolicitado = this.TieneSoli();// verifico si ya tiene una solicitud 

        if (!yaSolicitado) {
            let paseadorNuevo = new Contratacion(this.Logueado, paseadorASolicitar);
            let exitoSolicitud = this.AltaSolicitud(paseadorNuevo);
            Andres
            return true;

        } else {
            return false;
        }
    }


    GetPaseadorById(idBtnTocado) {//encuentra al paseador con el boton tocado
        for (let p of this.Paseador) {//  p recorre la lista de paseadores 
            if (p.Id == idBtnTocado) { // si el id del paseador donde se encuentra p es igual al id del boton tocado 
                return p; // devuelvo el paseador con el mismo id 
            }
        }
        return null;
    }

    TieneSoli() { // verifica si el paseador tiene solicitudes pendientes
        for (let p of this.Contrataciones) {
            if (this.Logueado.Id == p.Cliente.Id && p.Estado == "pendiente") {
                return true;
            }
        } return false;
    }

    ContratacionLogueado() { // retorna las solicitudes en pendiente del logueado
        for (let p of this.Contrataciones) {
            if (this.Logueado.Id == p.Cliente.Id && p.Estado === "pendiente") {
                return p;
            }
        } return null;
    }

    SolicitudAceptada() { // devuelve las solicitudes aceptadas del logueado 
        for (let p of this.Contrataciones) {
            if (this.Logueado.Id == p.Cliente.Id && p.Estado === "aceptada") {
                return p;
            }
        } return null;
    }

    AltaPaseador(_paseador) { //agrega un paseador nuevo a la lista
        this.Paseador.push(_paseador);
        return _paseador;
    }

    BuscarUsuarioParaLogin(n, p) { // busca entre los clientes y paseadores los datos ingresados y les asigna un rol para loguearlos
        for (let cliente of this.Cliente) { //por cada cliente de la lista de clientes verificar si los parametros se encuentran en la lista 
            if (cliente.NombreDeCliente == n && cliente.Password == p) {
                this.RolUsuarioLogueado = "cliente" // asigno rol
                this.Logueado = cliente; //guardo el objeto entero en logueado 
                return cliente;
            }
        }
        for (let paseador of this.Paseador) { //por cada paseador de la lista de paseadores verificar lo mismo
            if (paseador.NombreDePaseador == n && paseador.Password == p) {
                this.RolUsuarioLogueado = "paseador";
                this.Logueado = paseador;
                return paseador;
            }
        }
        return null;

    }


    //GetContrataciones(cliente, paseador) { // busca las contrataciones que tiene el paseador de los clientes que les solicitaron
    //    for (let cont of this.Contrataciones) {
    //        if (cont.Paseador.Id == paseador.Id && cont.Cliente.Id == cliente.Id && cont.Estado == "pendiente") {
    //            return cont;
    //        }
    //    }
    //    return null;
    //}
    //total de cupos ocupados
    



    GetClienteById(idBtnTocado) { // busca a un cliente recibiendo un id boton
        for (let c of this.Cliente) {
            if (Number(c.Id) === Number(idBtnTocado)) {
                return c;
            }
        }
        return null;
    }

    
TotalDeCuposOcupados(){  // calcula los cupos ocupados del paseador logueado
  let total = Number(this.Logueado.Cupos);
  let cupos = Number(this.CalcularCuposDisponibleDeUnPaseador(this.Logueado));      
  let calcularOcupados = total - cupos;
        return calcularOcupados;  
    }

TotalDeCuposMaximosDelPaseador() { 
        return this.Logueado.Cupos;
    }

PorcentajeDelTotalDeCupos(){ // calcula el porcentaje do cupos cocupados
        let total = Number(this.Logueado.Cupos);
        let cupos = Number(this.CalcularCuposDisponibleDeUnPaseador(this.Logueado));
        let calcularOcupados = total - cupos;
        let porcentaje = (calcularOcupados*100)/total 
        return porcentaje;
    }
    AceptarSolicitud(id) { // verifica todo antes de acetar una solicitud

        let contratacionEncontrada = null;
        
        for (let cont of this.Contrataciones) {
            if (cont.Id === id) {
                contratacionEncontrada = cont;
            }
        }
        let paseador = contratacionEncontrada.Paseador;
        let tamañoPerro = contratacionEncontrada.Cliente.TamañoPerro;
        let cuposDisponibles = this.CalcularCuposDisponibleDeUnPaseador(paseador);
        let chicoAceptada = this.ContienePerroChico(paseador);
        let grandeAceptada = this. ContienePerroGrande(paseador);
        
        
        if (!contratacionEncontrada) {
            return false;
        }

        if (contratacionEncontrada.Estado !== "pendiente") {
            return false;
        }

        if(tamañoPerro == 4 && chicoAceptada){
            return false;
        }

        if(tamañoPerro == 1 && grandeAceptada){
            return false;
        }


        if (tamañoPerro > cuposDisponibles) {
            return false;
        }
        contratacionEncontrada.Estado = "aceptada";
        cuposDisponibles -= tamañoPerro;
        
        return true;
    }


    // EN ACEPTAR LA SOLICITUD TIENE QUE DAR DE BAJA LAS INCOPATIBILIDADES DE LOS PERROS 



    CalcularCuposDisponibleDeUnPaseador(paseador) {  //detarmina los cupos disponibles para un paseador 
        let cuposOcupados = 0;
        for (let cont of this.Contrataciones) {  //recorro la lista de paseadores 
            if (cont.Paseador.Id === paseador.Id && cont.Estado === "aceptada") { //si el paseador es el asignado
                cuposOcupados += cont.Cliente.TamañoPerro; //le sumo el cupo del perro
            }
        }
        return paseador.Cupos - cuposOcupados;  //se lo resto al total de cupos del paseador asi me devuelve los cupos que le quedan
    }

    ObtenerPaseadoresCompatibles() { // devuelve los paseadores disponibles para un cliente  dependiendo de los cupos y los perros que tenga asignados 
        this.PaseadoresCompatibles = []; //vaciamos la lista

        let tamanio = this.Logueado.TamañoPerro; //identifico el tamanio del perro de la persona que esta logueada


        for (let paseador of this.Paseador) { //recorro la lista
            let cuposDisponiblesDeEstePaseador = this.CalcularCuposDisponibleDeUnPaseador(paseador); //llamo a la fincion pqra que me calcule los cupos dispoibles que tiene 


            if (tamanio === 4) {   // perro grande
                if (cuposDisponiblesDeEstePaseador >= tamanio && !this.ContienePerroChico(paseador)) { //aplico las condiciones de la letra para que lo muestre si tiene cupos y no tiene un perro que no sea compatible 
                    this.PaseadoresCompatibles.push(paseador)
                }
            }

            if (tamanio === 1) {  // perro chico
                if (cuposDisponiblesDeEstePaseador >= tamanio && !this.ContienePerroGrande(paseador)) { //lo mismo
                    this.PaseadoresCompatibles.push(paseador)
                }
            } else if (tamanio === 2) {//perro mediano
                if (cuposDisponiblesDeEstePaseador >= tamanio) {
                    this.PaseadoresCompatibles.push(paseador)
                }
            }

        }
        return this.PaseadoresCompatibles
    }

    //VERIFICACION DE TAMANIOS
    ContienePerroGrande(paseador) { // verifica si el paseador tiene un perro grande en las cotrataciones aceptadas

        for (let cont of this.Contrataciones) { //reccorro la lista de contrataciones 
            if (cont.Paseador === paseador && cont.Cliente.TamañoPerro == 4 && cont.Estado == "aceptada") {
                return true
            }

        }
        return false;
    }

    ContienePerroChico(paseador) {// verifica si el paseador tiene un perro chico en las cotrataciones aceptadas
        for (let cont of this.Contrataciones) {
            if (cont.Paseador === paseador && cont.Cliente.TamañoPerro === 1 && cont.Estado == "aceptada") {
                return true
            }

        }
        return false;

    }


    //PASEADORES
    PrecargarDatos() { //precarga de datos 
        this.AltaPaseador(new Paseador("Juan6", "Juan1", "Juan", 9))           // 0   
        this.AltaPaseador(new Paseador("Lucas2", "Lucas1", "Lucas", 6))        // 1
        this.AltaPaseador(new Paseador("Julieta1", "Julieta1", "Julieta", 7)) // 2    
        this.AltaPaseador(new Paseador("Gabriel1", "Gabriel1", "Gabriel", 9))// 3
        this.AltaPaseador(new Paseador("Martin5", "Martin1", "Martin", 6))     // 4
        this.AltaPaseador(new Paseador("Lucia2", "Lucia1", "lucia", 15))        // 5  


        // CLIENTES
        this.AltaCliente(new Cliente("Joel", "Joel1", "Firulais", 2, "Mediano"));   //0
        this.AltaCliente(new Cliente("Ana", "Ana12", "Luna", 4, "Grande"));           //1
        this.AltaCliente(new Cliente("Carlos", "Carlos1", "Rocky", 4, "Grande"));   //2
        this.AltaCliente(new Cliente("Guadalupe", "Guadalupe1", "Nina", 2, "Mediano"));     //3  
        this.AltaCliente(new Cliente("Pedro", "Pedro1", "Max", 4, "Grande"));       //4
        this.AltaCliente(new Cliente("Sofia", "Sofia1", "Boby", 1, "Chico"));       //5
        this.AltaCliente(new Cliente("Marcos", "Marcos1", "Toby", 2, "Mediano"));   //6
        this.AltaCliente(new Cliente("Elena", "Elena1", "Milo", 4, "Grande"));      //7
        this.AltaCliente(new Cliente("Jorge", "Jorge1", "Simba", 1, "Chico"));      //8
        this.AltaCliente(new Cliente("Carla", "Carla1", "Coco", 2, "Mediano"));     //9
        this.AltaCliente(new Cliente("Ernesto", "Ernesto1", "Zeus", 4, "Grande"));  //10
        this.AltaCliente(new Cliente("Valeria", "Valeria1", "Lola", 1, "Chico"));   //11
        this.AltaCliente(new Cliente("Diego", "Diego1", "Oso", 2, "Mediano"));      //12
        this.AltaCliente(new Cliente("Marta", "Marta1", "Chispa", 4, "Grande"));    //13
        this.AltaCliente(new Cliente("Nicolas", "Nicolas1", "Thor", 1, "Chico"));   //14
        this.AltaCliente(new Cliente("Laura", "Laura1", "Candy", 2, "Mediano"));    //15
        this.AltaCliente(new Cliente("Andres", "Andres1", "Balto", 4, "Grande"));   //16
        this.AltaCliente(new Cliente("Paula", "Paula1", "Nube", 1, "Chico"));       //17
        this.AltaCliente(new Cliente("Ruben", "Ruben1", "Tiger", 2, "Mediano"));    //18
        this.AltaCliente(new Cliente("Clara", "Clara1", "Bella", 4, "Grande"));     //19


        // CONTRATACIONES
        this.AltaSolicitud(new Contratacion(this.Cliente[0], this.Paseador[0]));
        this.AltaSolicitud(new Contratacion(this.Cliente[2], this.Paseador[2]));
        this.AltaSolicitud(new Contratacion(this.Cliente[7], this.Paseador[3]));
        this.AltaSolicitud(new Contratacion(this.Cliente[3], this.Paseador[2]));
        this.AltaSolicitud(new Contratacion(this.Cliente[4], this.Paseador[1]));
        this.AltaSolicitud(new Contratacion(this.Cliente[5], this.Paseador[5]));
        this.AltaSolicitud(new Contratacion(this.Cliente[6], this.Paseador[4]));
        this.AltaSolicitud(new Contratacion(this.Cliente[9], this.Paseador[4]));
        this.AltaSolicitud(new Contratacion(this.Cliente[17], this.Paseador[1]));
        this.AltaSolicitud(new Contratacion(this.Cliente[10], this.Paseador[4]));
    }

}
